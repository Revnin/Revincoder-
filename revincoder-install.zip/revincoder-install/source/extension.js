const vscode = require('vscode');
const path = require('path');
const { spawn } = require('child_process');

const GEMINI_KEY = 'revincoder.geminiKey';
const JOBS_KEY = 'revincoder.jobs';
const NEXT_ID_KEY = 'revincoder.nextJobId';

let stopFlag = false;   // cancel: abort everything and save progress
let paused = false;     // pause: typing waits, generation keeps streaming in the background
let busy = false;
let currentRun = null;
let abortCtl = null;
let statusItem;
let lastStatus = '';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rand = (a, b) => a + Math.random() * (b - a);

const cfg = () => {
  const c = vscode.workspace.getConfiguration('revincoder');
  return {
    cpm: Math.max(20, c.get('charsPerMinute')),
    variance: c.get('variance'),
    typoRate: c.get('typoRate'),
    lateFix: c.get('lateFixChance'),
    lateMin: Math.max(1, c.get('lateFixMinChars')),
    lateMax: Math.max(2, c.get('lateFixMaxChars')),
    reviewChance: c.get('reviewChance'),
    noticeMax: Math.max(0, c.get('typoNoticeMaxChars')),
    slowdown: Math.max(1, c.get('correctionSlowdown')),
    thinkChance: c.get('thinkChance'),
    thinkMin: c.get('thinkMinMs'),
    thinkMax: c.get('thinkMaxMs'),
    breakEvery: c.get('breakEveryMinutes'),
    breakSecs: c.get('breakSeconds'),
    fileSwitch: c.get('fileSwitchMs'),
    separateFolders: c.get('separateFolders'),
    jobPause: Math.max(0, c.get('jobPauseSeconds')),
    model: c.get('model'),
  };
};

// Optional chatty messages (run finished / cancelled). Errors, warnings and prompts are always shown.
function note(msg) {
  if (vscode.workspace.getConfiguration('revincoder').get('showProgressMessages')) vscode.window.showInformationMessage(msg);
}

function setStatus(text) {
  if (!vscode.workspace.getConfiguration('revincoder').get('showStatusBar')) { if (statusItem) statusItem.hide(); return; }
  if (!statusItem) {
    statusItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 0);
    statusItem.command = 'revincoder.pause';
  }
  if (text === null) { lastStatus = ''; statusItem.hide(); return; }
  lastStatus = text;
  if (paused) {
    statusItem.text = '$(debug-pause) Revincoder: PAUSED (Ctrl+Alt+Q to resume)';
    statusItem.tooltip = 'Click or press Ctrl+Alt+Q to resume. Ctrl+Alt+Shift+Q cancels and saves progress.';
  } else {
    statusItem.text = `$(keyboard) Revincoder: ${text}`;
    statusItem.tooltip = 'Click or press Ctrl+Alt+Q to pause. Ctrl+Alt+Shift+Q cancels and saves progress.';
  }
  statusItem.show();
}

async function pauseGate() {
  while (paused && !stopFlag) {
    setStatus(lastStatus || 'paused');
    await sleep(200);
  }
}

async function countdown(secs, label) {
  for (let s = Math.round(secs); s > 0 && !stopFlag; s--) {
    await pauseGate();
    setStatus(`${label} ${s}s`);
    await sleep(1000);
  }
}

/* ---------- typing engine ---------- */

function charDelay(ch, c) {
  let d = (60000 / c.cpm) * rand(1 - c.variance, 1 + c.variance);
  if (ch === ' ') d *= 1.2;
  if (ch === '\n') {
    d *= 2;
    if (Math.random() < c.thinkChance) d += rand(c.thinkMin, c.thinkMax);
  }
  return Math.max(5, d);
}

function docEnd(doc) {
  return doc.lineAt(doc.lineCount - 1).range.end;
}

async function insert(editor, s) {
  await editor.edit((b) => b.insert(docEnd(editor.document), s), { undoStopBefore: false, undoStopAfter: false });
  const end = docEnd(editor.document);
  editor.selection = new vscode.Selection(end, end);
  editor.revealRange(new vscode.Range(end, end));
}

async function backspace(editor) {
  const doc = editor.document;
  const end = docEnd(doc);
  const start = doc.positionAt(Math.max(0, doc.offsetAt(end) - 1));
  await editor.edit((b) => b.delete(new vscode.Range(start, end)), { undoStopBefore: false, undoStopAfter: false });
}

async function setDocText(editor, text) {
  const doc = editor.document;
  await editor.edit((b) => b.replace(new vscode.Range(doc.positionAt(0), docEnd(doc)), text), { undoStopBefore: false, undoStopAfter: false });
  const end = docEnd(editor.document);
  editor.selection = new vscode.Selection(end, end);
  editor.revealRange(new vscode.Range(end, end));
}

async function maybeBreak(c, state) {
  if (!c.breakEvery || Date.now() - state.lastBreak < c.breakEvery * 60000) return;
  await countdown(c.breakSecs * rand(0.8, 1.2), 'break');
  state.lastBreak = Date.now();
}

const NEIGHBORS = {
  q: 'wa', w: 'qes', e: 'wrd', r: 'etf', t: 'ryg', y: 'tuh', u: 'yij', i: 'uok', o: 'ipl', p: 'ol',
  a: 'qsz', s: 'awdx', d: 'sefc', f: 'drgv', g: 'fthb', h: 'gyjn', j: 'hukm', k: 'jilm', l: 'kop',
  z: 'asx', x: 'zsdc', c: 'xdfv', v: 'cfgb', b: 'vghn', n: 'bhjm', m: 'njk',
};

function adjacentKey(ch) {
  const n = NEIGHBORS[ch.toLowerCase()];
  if (!n) return null;
  const w = n[Math.floor(Math.random() * n.length)];
  return ch !== ch.toLowerCase() ? w.toUpperCase() : w;
}

// Picks a human-style mistake for the letter at text[i].
// wrong = what actually gets typed in place of text.slice(i, i + span); minLag = extra chars needed before it can be noticed.
function chooseMistake(text, i) {
  const ch = text[i];
  const next = text[i + 1];
  const r = Math.random();
  if (r < 0.45) {
    const a = adjacentKey(ch);
    return a ? { wrong: a, span: 1, minLag: 0 } : null;
  }
  if (r < 0.65 && next && /[a-z]/i.test(next) && next.toLowerCase() !== ch.toLowerCase()) {
    return { wrong: next + ch, span: 2, minLag: 0 }; // swapped letters ("teh")
  }
  if (r < 0.80 && next && next !== '\n') {
    return { wrong: '', span: 1, minLag: 1 }; // skipped letter, noticed a bit later
  }
  if (r < 0.80) {
    const a = adjacentKey(ch);
    return a ? { wrong: a, span: 1, minLag: 0 } : null;
  }
  return { wrong: ch + ch, span: 1, minLag: 0 }; // doubled letter
}

const NOUNDO = { undoStopBefore: false, undoStopAfter: false };

// "Mouse click": move the cursor somewhere else in the file and scroll it into view.
async function goTo(editor, pos, ms) {
  editor.selection = new vscode.Selection(pos, pos);
  editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType?.InCenterIfOutsideViewport);
  if (ms > 0) await sleep(ms);
}

// Go back to an earlier mistake, select it, fix it, then click back on the current line.
async function animateFix(editor, c, state) {
  const f = state.fix;
  if (!f || f.editor !== editor) return;
  const doc = editor.document;
  const range = () => new vscode.Range(doc.positionAt(f.off), doc.positionAt(f.off + f.cur.length));
  if (doc.getText(range()) !== f.cur) { // the file was changed by someone else: do not touch it
    state.fix = null;
    vscode.window.showWarningMessage('Revincoder: a typo could not be fixed because the file changed while typing.');
    return;
  }
  const nap = async (a, b) => { await pauseGate(); if (stopFlag) return false; await sleep(rand(a, b)); return !stopFlag; };
  if (!(await nap(400, 1100))) return;                              // notices the mistake
  await goTo(editor, doc.positionAt(f.off + f.cur.length), 0);       // click next to it
  if (!(await nap(500, 1200))) return;                               // mouse travel
  if (f.cur.length) {
    editor.selection = new vscode.Selection(doc.positionAt(f.off), doc.positionAt(f.off + f.cur.length)); // highlight it
    if (!(await nap(300, 800))) return;
    await editor.edit((b) => b.delete(range()), NOUNDO);
    f.cur = '';
    if (!(await nap(120, 350))) return;
  }
  for (const ch of f.right) {
    await pauseGate();
    if (stopFlag) return;
    await editor.edit((b) => b.insert(doc.positionAt(f.off + f.cur.length), ch), NOUNDO);
    f.cur += ch;
    const p = doc.positionAt(f.off + f.cur.length);
    editor.selection = new vscode.Selection(p, p);
    await sleep(charDelay(ch, c) * c.slowdown * rand(0.9, 1.3));
  }
  state.fix = null;
  if (!(await nap(400, 900))) return;
  await goTo(editor, docEnd(doc), 0);                                // click back on the current line
  await nap(300, 800);
}

// Instant version, used when cancelling so a half-fixed typo never gets saved.
async function finalizeFix(state) {
  const f = state.fix;
  if (!f) return;
  state.fix = null;
  const doc = f.editor.document;
  const range = new vscode.Range(doc.positionAt(f.off), doc.positionAt(f.off + f.cur.length));
  try {
    if (doc.getText(range) === f.cur) await f.editor.edit((b) => b.replace(range, f.right), NOUNDO);
  } catch { /* ignore */ }
}

async function flushFix(editor, c, state) {
  if (!state.fix || state.fix.editor !== editor) return;
  if (!stopFlag) await animateFix(editor, c, state);
  if (state.fix) await finalizeFix(state);
}

// Looks like someone scrolling back up to re-read something, then returning. No edit.
async function reviewEarlier(editor) {
  const doc = editor.document;
  const last = doc.lineCount - 1;
  if (last < 8) return;
  const ln = Math.floor(rand(Math.max(0, last - 60), last - 3));
  const text = doc.lineAt(ln).text || '';
  if (!text.trim()) return;
  await pauseGate();
  if (stopFlag) return;
  const col = Math.floor(rand(0, text.length));
  await goTo(editor, new vscode.Position(ln, col), rand(500, 1200));
  const words = [...text.matchAll(/\w+/g)].filter((m) => m.index + m[0].length > col);
  if (words.length && !stopFlag) {
    const w = words[0];
    editor.selection = new vscode.Selection(new vscode.Position(ln, w.index), new vscode.Position(ln, w.index + w[0].length));
    await sleep(rand(600, 1800));
  }
  if (!stopFlag) await sleep(rand(500, 1500));
  await goTo(editor, docEnd(doc), rand(300, 800));
}

async function typeText(editor, text, c, state, label, pct = true) {
  const total = text.length;
  const typeOne = async (ch, slow = 1, after) => {
    await pauseGate();
    await maybeBreak(c, state);
    if (stopFlag) return false;
    await insert(editor, ch);
    if (after) after();
    state.fixTyped = (state.fixTyped || 0) + 1;
    await sleep(charDelay(ch, c) * slow);
    return !stopFlag;
  };

  for (let i = 0; i < total; i++) {
    if (stopFlag) return;
    const ch = text[i];

    // Time to go back and fix an earlier mistake?
    if (state.fix && state.fix.editor === editor && (state.fixTyped || 0) >= state.fix.due && (i === 0 || /\s/.test(text[i - 1]))) {
      await animateFix(editor, c, state);
      if (stopFlag) return;
    }

    // Mistake: type it wrong, then either notice quickly (backspace + slow retype)
    // or leave it and go back to it later by "clicking" up to it.
    if (c.typoRate > 0 && /[a-z]/i.test(ch) && Math.random() < c.typoRate) {
      const m = chooseMistake(text, i);
      if (m) {
        if (!state.fix && c.lateFix > 0 && Math.random() < c.lateFix) {
          const doc = editor.document;
          const f = { editor, off: doc.offsetAt(docEnd(doc)), cur: '', right: text.slice(i, i + m.span), due: Math.floor(rand(c.lateMin, Math.max(c.lateMin + 1, c.lateMax))) };
          state.fix = f;
          state.fixTyped = 0;
          for (const t of m.wrong) if (!(await typeOne(t, 1, () => { f.cur += t; }))) return;
          i += m.span - 1;
          continue;
        }
        let room = 0;
        while (room < c.noticeMax && i + m.span + room < total && text[i + m.span + room] !== '\n') room++;
        if (room >= m.minLag) {
          const lag = Math.floor(rand(m.minLag, room + 1));
          const typed = m.wrong + text.slice(i + m.span, i + m.span + lag);
          for (const t of typed) if (!(await typeOne(t))) return;
          await sleep(rand(250, 800)); // notices the mistake
          for (let k = 0; k < typed.length; k++) {
            await pauseGate();
            if (stopFlag) return;
            await backspace(editor);
            await sleep(rand(50, 120));
          }
          await sleep(rand(150, 450));
          for (const t of text.slice(i, i + m.span + lag)) {
            if (!(await typeOne(t, c.slowdown * rand(0.9, 1.3)))) return;
          }
          i += m.span + lag - 1;
          continue;
        }
      }
    }

    if (!(await typeOne(ch))) return;
    if (ch === '\n' && c.reviewChance > 0 && !state.fix && Math.random() < c.reviewChance) await reviewEarlier(editor);
    if (i % 25 === 0) setStatus(pct ? `${label} ${Math.round((i / total) * 100)}%` : label);
  }
}

/* ---------- keep the computer awake while working ---------- */

// Builds the OS command for a small helper process that blocks sleep for as long as it runs.
// It exits on its own if VS Code's extension host disappears, so it can never keep the machine awake forever.
function awakeCommand(platform, pid, display) {
  if (platform === 'win32') {
    const flags = display ? 2147483651 : 2147483649; // ES_CONTINUOUS | ES_SYSTEM_REQUIRED (| ES_DISPLAY_REQUIRED)
    const script = `Add-Type -Namespace RC -Name P -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);'; ` +
      `while (Get-Process -Id ${pid} -ErrorAction SilentlyContinue) { [void][RC.P]::SetThreadExecutionState([uint32]${flags}); Start-Sleep -Seconds 20 }`;
    return { cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')] };
  }
  if (platform === 'darwin') return { cmd: 'caffeinate', args: [...(display ? ['-d'] : []), '-i', '-w', String(pid)] };
  return { cmd: 'systemd-inhibit', args: ['--what=idle:sleep', '--who=Revincoder', '--why=Typing code', '--mode=block', 'tail', `--pid=${pid}`, '-f', '/dev/null'] };
}

let awakeProc = null;
let awakeWarned = false;

function startAwake() {
  if (awakeProc) return;
  const conf = vscode.workspace.getConfiguration('revincoder');
  if (!conf.get('keepAwake')) return;
  const { cmd, args } = awakeCommand(process.platform, process.pid, !!conf.get('keepDisplayOn'));
  try {
    const p = spawn(cmd, args, { stdio: 'ignore', windowsHide: true });
    const warn = (why) => {
      if (awakeWarned) return;
      awakeWarned = true;
      vscode.window.showWarningMessage(`Revincoder: could not keep the computer awake automatically (${why}). Change your power settings so it does not sleep while typing.`);
    };
    p.on('error', () => { if (awakeProc === p) awakeProc = null; warn(`${cmd} is not available`); });
    p.on('exit', () => { if (awakeProc === p) { awakeProc = null; warn(`${cmd} stopped unexpectedly`); } }); // not our own stopAwake()
    awakeProc = p;
  } catch { /* ignore */ }
}

function stopAwake() {
  const p = awakeProc;
  if (!p) return;
  awakeProc = null; // clear first so the exit handler knows this stop was intentional
  try { p.kill(); } catch { /* ignore */ }
}

/* ---------- paths + files ---------- */

function safeRelPath(p) {
  if (typeof p !== 'string' || !p.trim()) throw new Error('File entry missing "path".');
  const n = path.posix.normalize(p.replace(/\\/g, '/'));
  if (n.startsWith('..') || path.posix.isAbsolute(n)) throw new Error(`Unsafe path in plan: ${p}`);
  return n;
}

function cleanPath(p) {
  return p.replace(/[`*"']/g, '').replace(/^\.\//, '').replace(/\\/g, '/').trim();
}

// keep=true: reopen a half-typed file without wiping it (used when resuming).
async function openForTyping(root, relRaw, subdir, keep = false) {
  const rel = safeRelPath(relRaw);
  const full = subdir ? `${subdir}/${rel}` : rel;
  const uri = vscode.Uri.joinPath(root, full);
  await vscode.workspace.fs.createDirectory(vscode.Uri.joinPath(uri, '..'));
  let doc = null;
  let existing = '';
  if (keep) {
    try { doc = await vscode.workspace.openTextDocument(uri); existing = doc.getText(); } catch { doc = null; }
  }
  if (!doc) {
    await vscode.workspace.fs.writeFile(uri, new Uint8Array());
    doc = await vscode.workspace.openTextDocument(uri);
    existing = '';
  }
  const editor = await vscode.window.showTextDocument(doc, { preview: false });
  if (!existing) await sleep(rand(400, 900));
  return { rel: full, doc, editor, existing };
}

/* ---------- plan (JSON) mode ---------- */

async function runPlan(plan, { subdir, state, label = '' } = {}) {
  const root = vscode.workspace.workspaceFolders?.[0]?.uri;
  if (!root) return { status: 'error', error: 'Open a folder in VS Code first.' };
  if (!plan || !Array.isArray(plan.files) || !plan.files.length) return { status: 'error', error: 'Plan needs a non-empty "files" array.' };
  const c = cfg();
  state = state || { lastBreak: Date.now() };
  try {
    for (let n = 0; n < plan.files.length && !stopFlag; n++) {
      const f = plan.files[n];
      const { rel, doc, editor } = await openForTyping(root, f.path, subdir);
      const content = String(f.content ?? '').replace(/\r\n/g, '\n');
      await typeText(editor, content, c, state, `${label} ${rel} (${n + 1}/${plan.files.length})`.trim());
      await flushFix(editor, c, state);
      await doc.save();
      if (!stopFlag) await sleep(c.fileSwitch * rand(0.7, 1.4));
    }
  } catch (e) {
    return { status: 'error', error: e.message };
  }
  return { status: stopFlag ? 'stopped' : 'ok', files: plan.files.length };
}

/* ---------- streaming: Gemini output -> queue of typing events ---------- */

const SYSTEM_PROMPT = `You are a senior software engineer. Given a project request, output a complete, working project as plain-text files using EXACTLY this format, with nothing before, between or after the blocks (no commentary, no markdown fences):
=== FILE: relative/path.ext ===
<raw file content, no escaping>
=== END FILE ===
Rules: include source, config, dependency manifest and a short README. Use relative paths only. Order files so config/manifests come first, then source. Keep the project compact. Code must be correct and runnable.`;

const CONTINUE_PROMPT = 'Your previous answer was interrupted. Continue EXACTLY where it stopped, starting with the very next line after the last line above. Output ONLY the remaining text in the same format. Do not repeat anything already written. If you were in the middle of a file, continue that file from the next line (do not repeat its "=== FILE:" header), close it with "=== END FILE ===", then write any remaining files.';

const FILE_RE = /^[^\w\n]*={2,}\s*FILE:\s*(.+?)\s*=*[^\w\n]*$/i;
const END_RE = /^[^\w\n]*={2,}\s*END FILE\s*=*[^\w\n]*$/i;

class Queue {
  constructor() { this.items = []; this.waiters = []; this.closed = false; }
  push(x) { if (this.waiters.length) this.waiters.shift()(x); else this.items.push(x); }
  close() { this.closed = true; this.waiters.forEach((w) => w(null)); this.waiters = []; }
  next() {
    if (this.items.length) return Promise.resolve(this.items.shift());
    if (this.closed) return Promise.resolve(null);
    return new Promise((r) => this.waiters.push(r));
  }
}

function newFeed() { return { buf: '', cur: false, first: false, held: null }; }

function closeFile(st, q) {
  if (st.cur) q.push({ t: 'end' });
  st.cur = false; st.first = false; st.held = null;
}

function handleLine(st, line, q) {
  const start = line.match(FILE_RE);
  if (start) { closeFile(st, q); q.push({ t: 'file', path: cleanPath(start[1]) }); st.cur = true; st.first = true; return; }
  if (END_RE.test(line)) { closeFile(st, q); return; }
  if (!st.cur) return;
  if (st.first) { st.first = false; if (/^\s*```[\w+.-]*\s*$/.test(line)) return; }
  if (st.held !== null) { q.push({ t: 'text', text: st.held + '\n' }); st.held = null; }
  if (/^\s*```\s*$/.test(line)) { st.held = line; return; }
  q.push({ t: 'text', text: line + '\n' });
}

function feed(st, text, q) {
  st.buf += text;
  let nl;
  while ((nl = st.buf.indexOf('\n')) >= 0) {
    handleLine(st, st.buf.slice(0, nl).replace(/\r$/, ''), q);
    st.buf = st.buf.slice(nl + 1);
  }
}

function endFeed(st, q) {
  if (st.buf) { handleLine(st, st.buf, q); st.buf = ''; }
  closeFile(st, q);
}

// When continuing an interrupted answer, models sometimes repeat the last lines. Drop that overlap.
function makeDedupe(prevText, emit) {
  let buf = '';
  let done = false;
  const prevLines = prevText.split('\n');
  prevLines.pop();
  const apply = () => {
    done = true;
    const lines = buf.split('\n');
    const tail = prevLines.slice(-8);
    let drop = 0;
    for (let k = Math.min(tail.length, lines.length - 1); k >= 1; k--) {
      const a = tail.slice(tail.length - k);
      const b = lines.slice(0, k);
      if (a.every((x, i) => x === b[i]) && (k >= 2 || FILE_RE.test(a[0]))) { drop = k; break; }
    }
    const out = lines.slice(drop).join('\n');
    buf = '';
    if (out) emit(out);
  };
  return {
    push(t) {
      if (done) { emit(t); return; }
      buf += t;
      if ((buf.match(/\n/g) || []).length >= 10) apply();
    },
    flush() { if (!done) apply(); },
  };
}

async function readSSE(body, onText) {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let sse = '';
  let finish = null;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    sse += dec.decode(value, { stream: true });
    let idx;
    while ((idx = sse.indexOf('\n')) >= 0) {
      const line = sse.slice(0, idx).replace(/\r$/, '');
      sse = sse.slice(idx + 1);
      if (!line.startsWith('data:')) continue;
      const j = line.slice(5).trim();
      if (!j) continue;
      let o;
      try { o = JSON.parse(j); } catch { continue; }
      const cand = o.candidates?.[0];
      if (cand?.finishReason) finish = cand.finishReason;
      const t = (cand?.content?.parts || []).map((p) => p.text || '').join('');
      if (t) onText(t);
    }
  }
  return finish;
}

// retryAfter (seconds) marks errors worth retrying automatically: rate limits, overload, lost connection.
function apiError(message, retryAfter = 0) {
  const e = new Error(message);
  e.retryAfter = retryAfter;
  return e;
}

// Laptop sleep, Wi-Fi drops and VPN switches all surface as a failed fetch or a stream that dies half-way.
function networkError(e) {
  if (e && e.name === 'AbortError') return e;
  const ne = apiError(`Lost connection to Gemini (${(e && (e.cause?.code || e.message)) || 'network error'}).`, -1);
  ne.network = true;
  return ne;
}

// cont = text already received (full lines) when continuing an interrupted answer, else null.
async function produce({ ctx, key, model, request, q, st, signal, raw, cont }) {
  const contents = [{ role: 'user', parts: [{ text: request }] }];
  if (cont) {
    contents.push({ role: 'model', parts: [{ text: cont }] });
    contents.push({ role: 'user', parts: [{ text: CONTINUE_PROMPT }] });
  }
  let res;
  try {
    res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`, {
      method: 'POST',
      signal,
      headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents,
        generationConfig: { maxOutputTokens: 32000 },
      }),
    });
  } catch (e) {
    throw networkError(e);
  }
  if (!res.ok) {
    const body = (await res.text()).slice(0, 300);
    if (res.status === 400 && /API key/i.test(body)) {
      await ctx.secrets.delete(GEMINI_KEY);
      throw apiError('Gemini rejected the API key. Run "Revincoder: Set Gemini API key" and try again.');
    }
    if (res.status === 404) throw apiError(`Model "${model}" not found. Change revincoder.model in settings.`);
    if (res.status === 429) throw apiError('Gemini rate/quota limit hit.', 65);
    if (res.status === 503) throw apiError('Gemini is overloaded right now.', 30);
    throw apiError(`Gemini API ${res.status}: ${body}`);
  }
  const emit = (t) => { raw.text += t; feed(st, t, q); };
  const sink = cont ? makeDedupe(cont, emit) : { push: emit, flush() {} };
  let finish;
  try {
    finish = await readSSE(res.body, (t) => sink.push(t));
  } catch (e) {
    throw networkError(e);
  } finally {
    sink.flush();
  }
  endFeed(st, q);
  return finish;
}

/* ---------- fallback: parse a complete response ---------- */

function stripFence(s) {
  const m = s.match(/^\s*```[^\n]*\n([\s\S]*?)\n\s*```\s*$/);
  return m ? m[1] : s;
}

function parsePlan(text) {
  text = text.replace(/\r\n/g, '\n');
  const files = [];
  let cur = null;
  const flush = () => {
    if (cur && cur.path) files.push({ path: cur.path, content: stripFence(cur.lines.join('\n')).replace(/\s+$/, '') + '\n' });
    cur = null;
  };
  for (const line of text.split('\n')) {
    const start = line.match(FILE_RE);
    if (start) { flush(); cur = { path: cleanPath(start[1]), lines: [] }; continue; }
    if (END_RE.test(line)) { flush(); continue; }
    if (cur) cur.lines.push(line);
  }
  flush();
  if (files.length) return { files };

  const md = /(?:^|\n)[ \t]*(?:#+[ \t]*|[*_`]+|\d+\.[ \t]*|File:[ \t]*|[-][ \t]*)?([\w@.\-/\\]+\.[A-Za-z0-9]+|Dockerfile|Makefile)[*_`:]*[ \t]*\n+```[^\n]*\n([\s\S]*?)\n```/g;
  let m;
  while ((m = md.exec(text))) files.push({ path: cleanPath(m[1]), content: m[2].replace(/\s+$/, '') + '\n' });
  if (files.length) return { files };

  const s = text.indexOf('{');
  const e = text.lastIndexOf('}');
  if (s >= 0 && e > s) {
    try { return JSON.parse(text.slice(s, e + 1)); } catch { /* fall through */ }
  }
  return null;
}

/* ---------- one generate-and-type job (resumable) ---------- */

// seed = { raw, complete, finish, filesDone } from an earlier interrupted run of the same job.
async function runStream(ctx, key, request, { subdir, state, label = '', seed, onCheckpoint } = {}) {
  const root = vscode.workspace.workspaceFolders?.[0]?.uri;
  if (!root) return { status: 'error', error: 'Open a folder in VS Code first.' };
  const c = cfg();
  state = state || { lastBreak: Date.now() };
  const q = new Queue();
  const st = newFeed();
  const hasSeed = !!(seed && seed.raw);
  const seedFiles = hasSeed ? seed.filesDone || 0 : 0;
  const raw = { text: hasSeed ? seed.raw : '' };
  let perr = null;
  let finish = hasSeed && seed.complete ? seed.finish || 'STOP' : null;
  let files = 0;
  let filesCompleted = 0;
  let fileIdx = -1;
  let skipping = false;
  let doc = null;
  let editor = null;
  let rel = '';
  let resumeBuf = null; // what is already in the half-typed file, compared with the incoming text
  let matched = '';

  const snapshot = () => {
    const complete = finish !== null;
    return {
      raw: complete ? raw.text : raw.text.slice(0, raw.text.lastIndexOf('\n') + 1),
      complete,
      finish: finish || undefined,
      filesDone: filesCompleted,
    };
  };
  const saveCheckpoint = async () => { if (onCheckpoint) { const cp = snapshot(); if (cp.raw) await onCheckpoint(cp); } };

  abortCtl = new AbortController();
  setStatus(`${label} ${hasSeed ? 'resuming...' : 'connecting to Gemini...'}`.trim());

  let prod;
  if (hasSeed) feed(st, seed.raw, q); // replay what we already know; the consumer skips/matches what is already typed
  if (hasSeed && seed.complete) {
    endFeed(st, q);
    q.close();
    prod = Promise.resolve();
  } else {
    prod = produce({ ctx, key, model: c.model, request, q, st, signal: abortCtl.signal, raw, cont: hasSeed ? seed.raw : null })
      .then((f) => { finish = f || 'STOP'; }, (e) => { perr = e; })
      .finally(() => q.close());
  }

  const finishResume = async (extra) => {
    if (!editor || resumeBuf === null) return;
    const want = matched + extra;
    if (doc.getText() !== want) await setDocText(editor, want);
    resumeBuf = null;
    matched = '';
  };

  try {
    while (!stopFlag) {
      await pauseGate();
      const ev = await q.next();
      if (!ev) break;
      if (ev.t === 'file') {
        fileIdx++;
        files++;
        if (fileIdx < seedFiles) { skipping = true; continue; }
        const keep = hasSeed && fileIdx === seedFiles;
        const o = await openForTyping(root, ev.path, subdir, keep);
        ({ rel, doc, editor } = o);
        resumeBuf = keep && o.existing ? o.existing : null;
        matched = '';
      } else if (ev.t === 'text') {
        if (skipping || !editor) continue;
        let t = ev.text;
        if (resumeBuf !== null) {
          const m = Math.min(resumeBuf.length, t.length);
          let n = 0;
          while (n < m && resumeBuf[n] === t[n]) n++;
          if (n === t.length) { // this chunk is already typed
            matched += t;
            resumeBuf = resumeBuf.slice(t.length);
            setStatus(`${label} ${rel} (resuming)`.trim());
            continue;
          }
          await finishResume(t.slice(0, n)); // keep the correct typed part, drop anything wrong after it
          t = t.slice(n);
        }
        if (t) await typeText(editor, t, c, state, `${label} ${rel}`.trim(), false);
      } else if (ev.t === 'end') {
        if (skipping) { skipping = false; filesCompleted++; continue; }
        if (resumeBuf !== null) await finishResume('');
        await flushFix(editor, c, state);
        if (doc) await doc.save();
        doc = null; editor = null;
        filesCompleted++;
        await saveCheckpoint();
        if (!stopFlag) await sleep(c.fileSwitch * rand(0.7, 1.4));
      }
    }
    if (stopFlag && abortCtl) abortCtl.abort();
    await prod;
    await finalizeFix(state); // never save a file with an unfixed typo left in it
    if (doc) await doc.save(); // keep the half-typed file on disk so we can pick up from it
  } catch (e) {
    perr = perr || e;
    if (abortCtl) abortCtl.abort();
    try { await finalizeFix(state); if (doc) await doc.save(); } catch { /* ignore */ }
  } finally {
    abortCtl = null;
  }

  const cp = snapshot();
  if (stopFlag) {
    await saveCheckpoint();
    return { status: 'stopped', files, checkpoint: cp.raw ? cp : seed };
  }
  if (perr && perr.name !== 'AbortError') {
    await saveCheckpoint();
    return { status: 'error', error: perr.message, retryAfter: perr.retryAfter || 0, files, checkpoint: cp.raw ? cp : seed };
  }
  if (!files) {
    const plan = parsePlan(raw.text);
    if (plan) return runPlan(plan, { subdir, state, label });
    try { await vscode.workspace.fs.writeFile(vscode.Uri.joinPath(root, 'revincoder.raw.txt'), Buffer.from(raw.text, 'utf8')); } catch { /* ignore */ }
    return { status: 'error', error: `Could not find any files in the model output (finishReason: ${finish || 'none'}, ${raw.text.length} chars). Raw output saved to revincoder.raw.txt.` };
  }
  return { status: finish === 'MAX_TOKENS' ? 'cut' : 'ok', files };
}

/* ---------- job queue ---------- */

const getJobs = (ctx) => (ctx.workspaceState.get(JOBS_KEY, []) || []).map((j) => (j.status === 'running' ? { ...j, status: 'pending' } : j));
const saveJobs = (ctx, jobs) => ctx.workspaceState.update(JOBS_KEY, jobs);

function slug(s) {
  const t = s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').split('-').slice(0, 4).join('-').slice(0, 28);
  return t || 'project';
}

async function addJob(ctx, prompt, { single = false } = {}) {
  const id = ctx.workspaceState.get(NEXT_ID_KEY, 1);
  await ctx.workspaceState.update(NEXT_ID_KEY, id + 1);
  const job = { id, prompt: prompt.trim(), status: 'pending', folder: single ? '' : `${String(id).padStart(2, '0')}-${slug(prompt)}` };
  await saveJobs(ctx, [...getJobs(ctx), job]);
  return job;
}

async function patchJob(ctx, id, patch) {
  await saveJobs(ctx, getJobs(ctx).map((j) => (j.id === id ? { ...j, ...patch } : j)));
}

async function ensureKey(ctx) {
  let key = await ctx.secrets.get(GEMINI_KEY);
  if (!key) {
    key = await vscode.window.showInputBox({ prompt: 'Google Gemini API key (free at aistudio.google.com/apikey)', password: true, ignoreFocusOut: true });
    if (!key) return null;
    key = key.trim();
    await ctx.secrets.store(GEMINI_KEY, key);
  }
  return key;
}

async function withBusy(fn) {
  if (busy) { vscode.window.showWarningMessage('Revincoder is already running. Ctrl+Alt+Q pauses/resumes it.'); return; }
  busy = true;
  stopFlag = false;
  paused = false;
  startAwake();
  const p = (async () => fn())();
  currentRun = p;
  try { return await p; } finally { busy = false; paused = false; currentRun = null; stopAwake(); setStatus(null); }
}

async function runQueue(ctx, onlyId) {
  const root = vscode.workspace.workspaceFolders?.[0]?.uri;
  if (!root) return vscode.window.showErrorMessage('Open a folder in VS Code first.');
  const eligible = (j) => j.status === 'pending' && (!onlyId || j.id === onlyId);
  if (!getJobs(ctx).some(eligible)) return vscode.window.showInformationMessage('Revincoder: no pending jobs. Use "Add jobs to queue".');
  return withBusy(async () => {
    const key = await ensureKey(ctx);
    if (!key) return;
    const c = cfg();
    const state = { lastBreak: Date.now() };
    let done = 0;
    let failed = 0;
    while (!stopFlag) {
      const jobs = getJobs(ctx);
      const job = jobs.find(eligible);
      if (!job) break;
      const label = onlyId ? '' : `job ${jobs.indexOf(job) + 1}/${jobs.length}`;
      let seed = job.checkpoint;
      await patchJob(ctx, job.id, { status: 'running' });
      let res;
      for (let attempt = 0; attempt < 12; attempt++) {
        res = await runStream(ctx, key, job.prompt, {
          subdir: c.separateFolders && job.folder ? job.folder : undefined,
          state,
          label,
          seed,
          onCheckpoint: (cp) => patchJob(ctx, job.id, { checkpoint: cp }),
        });
        if (res.checkpoint) seed = res.checkpoint;
        if (res.status === 'error' && res.retryAfter && !stopFlag) {
          const network = res.retryAfter < 0;
          if (attempt >= (network ? 11 : 2)) break;
          // lost connection (e.g. the laptop slept): wait a little for the network, then continue from the saved spot
          await countdown(network ? Math.min(10 * (attempt + 1), 30) : res.retryAfter, `${label} ${network ? 'connection lost, resuming in' : 'Gemini busy, retrying in'}`.trim());
          if (stopFlag) break;
          continue;
        }
        break;
      }
      if (stopFlag || res.status === 'stopped') { await patchJob(ctx, job.id, { status: 'pending', checkpoint: seed }); break; }
      if (res.status === 'error') {
        failed++;
        await patchJob(ctx, job.id, { status: 'failed', error: res.error, checkpoint: seed });
        vscode.window.showWarningMessage(`Revincoder: ${label || 'job'} failed: ${res.error}`.replace('  ', ' '));
      } else {
        done++;
        await patchJob(ctx, job.id, { status: 'done', error: undefined, checkpoint: undefined });
        if (res.status === 'cut') vscode.window.showWarningMessage('Revincoder: output was cut off, the last file may be incomplete.');
      }
      if (getJobs(ctx).some(eligible)) await countdown(c.jobPause * rand(0.8, 1.3), 'next job in');
    }
    if (stopFlag) note(`Revincoder cancelled. Progress saved: press Ctrl+Alt+Q (or run "Run queue") to continue exactly where it stopped. ${done} job(s) finished.`);
    else note(`Revincoder finished: ${done} done, ${failed} failed.`);
  });
}

async function addJobsCommand(ctx) {
  let n = 0;
  for (;;) {
    const count = getJobs(ctx).length + 1;
    const p = await vscode.window.showInputBox({ prompt: `Job ${count}: what should Revincoder build? (leave empty and press Enter to finish)`, ignoreFocusOut: true });
    if (!p || !p.trim()) break;
    await addJob(ctx, p);
    n++;
  }
  if (!n) return;
  const pick = await vscode.window.showInformationMessage(`${n} job(s) added to the queue.`, 'Run queue now');
  if (pick === 'Run queue now') await runQueue(ctx);
}

async function importJobsCommand(ctx) {
  const pick = await vscode.window.showOpenDialog({ canSelectMany: false, filters: { Text: ['txt', 'md'] } });
  if (!pick) return;
  const text = Buffer.from(await vscode.workspace.fs.readFile(pick[0])).toString('utf8').replace(/\r\n/g, '\n');
  const blocks = text.split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean);
  const items = blocks.length > 1 ? blocks : text.split('\n').map((s) => s.trim()).filter(Boolean);
  for (const it of items) await addJob(ctx, it.replace(/\s*\n\s*/g, ' '));
  const choice = await vscode.window.showInformationMessage(`Imported ${items.length} job(s).`, 'Run queue now');
  if (choice === 'Run queue now') await runQueue(ctx);
}

async function viewQueueCommand(ctx) {
  const jobs = getJobs(ctx);
  if (!jobs.length) return vscode.window.showInformationMessage('Revincoder: the queue is empty.');
  const icon = { pending: '$(circle-outline)', running: '$(sync)', done: '$(check)', failed: '$(error)' };
  const picked = await vscode.window.showQuickPick(
    jobs.map((j, i) => ({
      label: `${icon[j.status] || ''} ${i + 1}. ${j.prompt.slice(0, 70)}`,
      description: j.status + (j.checkpoint ? ` (can resume, ${j.checkpoint.filesDone} file(s) already typed)` : ''),
      detail: j.error || j.folder || '(project root)',
      job: j,
    })),
    { canPickMany: true, placeHolder: 'Tick jobs to REMOVE, then press Enter (Esc to just close)' }
  );
  if (!picked || !picked.length) return;
  if (busy) return vscode.window.showWarningMessage('Revincoder: cancel the run before removing jobs.');
  const ids = new Set(picked.map((p) => p.job.id));
  await saveJobs(ctx, getJobs(ctx).filter((j) => !ids.has(j.id)));
}

async function clearQueueCommand(ctx) {
  if (busy) return vscode.window.showWarningMessage('Revincoder: cancel the run first.');
  const pick = await vscode.window.showQuickPick(['Re-run failed jobs', 'Restart interrupted jobs from scratch', 'Clear finished jobs', 'Clear all jobs'], { placeHolder: 'Queue maintenance' });
  if (!pick) return;
  const jobs = getJobs(ctx);
  if (pick === 'Clear all jobs') await saveJobs(ctx, []);
  else if (pick === 'Clear finished jobs') await saveJobs(ctx, jobs.filter((j) => j.status !== 'done'));
  else if (pick === 'Restart interrupted jobs from scratch') await saveJobs(ctx, jobs.map((j) => (j.status !== 'done' ? { ...j, status: 'pending', error: undefined, checkpoint: undefined } : j)));
  else await saveJobs(ctx, jobs.map((j) => (j.status === 'failed' ? { ...j, status: 'pending', error: undefined } : j)));
}

// Ctrl+Alt+Q: pause / resume while running; when idle, continue the saved queue.
async function pauseToggle(ctx) {
  if (busy) {
    paused = !paused;
    if (paused) stopAwake(); else startAwake(); // a paused run no longer keeps the computer awake
    setStatus(lastStatus || 'working');
    return;
  }
  if (getJobs(ctx).some((j) => j.status === 'pending')) return runQueue(ctx);
  vscode.window.showInformationMessage('Revincoder: nothing to pause or resume. Use "Add jobs to queue" to start.');
}

/* ---------- activation ---------- */

function activate(ctx) {
  ctx.subscriptions.push(
    vscode.commands.registerCommand('revincoder.addJobs', () => addJobsCommand(ctx)),
    vscode.commands.registerCommand('revincoder.importJobs', () => importJobsCommand(ctx)),
    vscode.commands.registerCommand('revincoder.runQueue', () => runQueue(ctx)),
    vscode.commands.registerCommand('revincoder.viewQueue', () => viewQueueCommand(ctx)),
    vscode.commands.registerCommand('revincoder.clearQueue', () => clearQueueCommand(ctx)),
    vscode.commands.registerCommand('revincoder.generate', async () => {
      if (!vscode.workspace.workspaceFolders?.length) return vscode.window.showErrorMessage('Open a folder in VS Code first.');
      if (busy) return vscode.window.showWarningMessage('Revincoder is already running. Ctrl+Alt+Q pauses/resumes it.');
      const request = await vscode.window.showInputBox({ prompt: 'What should Revincoder build?', ignoreFocusOut: true });
      if (!request) return;
      const job = await addJob(ctx, request, { single: true });
      await runQueue(ctx, job.id);
    }),
    vscode.commands.registerCommand('revincoder.run', async () => {
      const root = vscode.workspace.workspaceFolders?.[0]?.uri;
      const pick = await vscode.window.showOpenDialog({ defaultUri: root, canSelectMany: false, filters: { JSON: ['json'] } });
      if (!pick) return;
      await withBusy(async () => {
        try {
          const plan = JSON.parse(Buffer.from(await vscode.workspace.fs.readFile(pick[0])).toString('utf8'));
          const res = await runPlan(plan);
          if (res.status === 'error') vscode.window.showErrorMessage(`Revincoder: ${res.error}`);
          else note(res.status === 'stopped' ? 'Revincoder cancelled.' : 'Revincoder finished.');
        } catch (e) { vscode.window.showErrorMessage(`Revincoder: ${e.message}`); }
      });
    }),
    vscode.commands.registerCommand('revincoder.pause', () => pauseToggle(ctx)),
    vscode.commands.registerCommand('revincoder.stop', () => { stopFlag = true; paused = false; if (abortCtl) abortCtl.abort(); }),
    vscode.commands.registerCommand('revincoder.setApiKey', async () => {
      const k = await vscode.window.showInputBox({ prompt: 'Google Gemini API key', password: true, ignoreFocusOut: true });
      if (k) await ctx.secrets.store(GEMINI_KEY, k.trim());
    })
  );
}

// VS Code closing counts as a cancel: progress is saved so the job can continue next time.
function deactivate() {
  stopAwake();
  stopFlag = true;
  paused = false;
  if (abortCtl) abortCtl.abort();
  return currentRun ? Promise.race([currentRun.catch(() => {}), sleep(4000)]) : undefined;
}

module.exports = { activate, deactivate };
